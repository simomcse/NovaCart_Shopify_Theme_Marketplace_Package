/* NovaCart entry – runtime in novacart-app.js */
document.documentElement.classList.remove('no-js');
document.documentElement.classList.add('js');
