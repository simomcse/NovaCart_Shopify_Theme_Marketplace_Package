NovaCart modular assets
=======================

CSS load order (layout/theme.liquid):
  1. base.css           Design tokens, reset, utilities, buttons, forms
  2. layout.css         Announcement, header, mobile nav, marquee
  3. components.css     Product cards, collection toolbar
  4. product.css        Product page
  5. cart.css           Cart drawer, footer, promo, reels, cart page
  6. overlays.css       Dialogs, accessibility, RTE
  7. sidebar.css        Store sidebar, language/currency selectors
  8. schemes.css        Color schemes
  9. categories.css     Categories section
 10. search.css         Predictive search overlay
 11. filters-auth.css   Collection filters + auth pages
 12. features.css       Size chart, FBT, shipping, collection extras, products grid

JS load order:
  1. novacart-app.js    All storefront interactions (search section comments to edit)
  2. theme.js           Entry marker

JS section comments inside novacart-app.js:
  - Display currency switcher
  - Storefront theme color switcher
  - Size chart modal
  - Shipping calculator
  - Frequently bought together
  - Collection: view mode + quick add
  - Product / Quick View / Cart drawer / Marketing popup
