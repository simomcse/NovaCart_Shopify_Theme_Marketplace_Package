/* NovaCart module source: 03-product-features.js
   Loaded as part of novacart-app.js — edit here then rebuild, or edit novacart-app.js directly.
*/
/* ---------- Size chart modal ---------- */
  function initSizeChart() {
    const dialog = document.querySelector('[data-size-chart-dialog]');
    if (!dialog) return;
    const openBtns = document.querySelectorAll('[data-size-chart-open]');
    const closeBtn = dialog.querySelector('[data-size-chart-close]');
    openBtns.forEach((btn) => btn.addEventListener('click', () => {
      if (typeof dialog.showModal === 'function') dialog.showModal();
      else dialog.setAttribute('open', '');
    }));
    closeBtn?.addEventListener('click', () => {
      if (typeof dialog.close === 'function') dialog.close();
      else dialog.removeAttribute('open');
    });
    dialog.addEventListener('click', (e) => {
      if (e.target === dialog) {
        if (typeof dialog.close === 'function') dialog.close();
        else dialog.removeAttribute('open');
      }
    });
  }

  /* ---------- Shipping calculator ---------- */
  function initShippingCalculator() {
    document.querySelectorAll('[data-shipping-calculator]').forEach((root) => {
      const select = root.querySelector('[data-ship-country]');
      const result = root.querySelector('[data-ship-result]');
      const btn = root.querySelector('[data-ship-estimate]');
      if (!select || !result || !btn) return;
      btn.addEventListener('click', () => {
        const opt = select.options[select.selectedIndex];
        if (!opt) return;
        const rate = parseFloat(opt.getAttribute('data-rate') || '0');
        const days = opt.getAttribute('data-days') || '';
        const label = opt.getAttribute('data-label') || opt.textContent.trim();
        const zip = (root.querySelector('[data-ship-zip]')?.value || '').trim();
        let text;
        if (!isFinite(rate) || rate <= 0) {
          text = `✓ ${label}: Free shipping` + (days ? ` · ${days}` : '');
        } else {
          const formatted = (typeof formatDisplayMoney === 'function')
            ? formatDisplayMoney(rate)
            : (rate.toFixed(2) + ' ' + (document.documentElement.getAttribute('data-default-currency') || 'USD'));
          text = `✓ ${label}: ${formatted}` + (days ? ` · ${days}` : '');
        }
        if (zip) text += ` · ZIP ${zip}`;
        result.hidden = false;
        result.textContent = text;
      });
    });
  }

  /* ---------- Frequently bought together ---------- */
  function initFbt() {
    const root = document.querySelector('[data-fbt]');
    if (!root) return;
    const totalEl = root.querySelector('[data-fbt-total]');
    const status = root.querySelector('[data-fbt-status]');
    const addBtn = root.querySelector('[data-fbt-add]');
    const moneyFormat = totalEl?.getAttribute('data-money-format') || '';

    function selectedItems() {
      return Array.from(root.querySelectorAll('[data-fbt-main], [data-fbt-item]')).filter((el) => el.checked);
    }

    function updateTotal() {
      if (!totalEl) return;
      let cents = 0;
      selectedItems().forEach((el) => {
        cents += parseInt(el.getAttribute('data-price') || '0', 10) || 0;
      });
      if (typeof money === 'function') {
        totalEl.textContent = money(cents, moneyFormat);
      } else {
        totalEl.textContent = (cents / 100).toFixed(2);
      }
      if (typeof applyCurrencyConversion === 'function') {
        try { applyCurrencyConversion(); } catch (e) {}
      }
    }

    root.querySelectorAll('[data-fbt-item]').forEach((el) => {
      el.addEventListener('change', updateTotal);
    });
    updateTotal();

    addBtn?.addEventListener('click', async () => {
      const items = selectedItems().map((el) => ({
        id: Number(el.value),
        quantity: 1
      })).filter((item) => item.id);
      if (!items.length) return;
      addBtn.disabled = true;
      if (status) {
        status.hidden = false;
        status.textContent = '…';
      }
      try {
        const res = await fetch('/cart/add.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify({ items })
        });
        if (!res.ok) throw new Error('add failed');
        if (status) status.textContent = root.dataset.successLabel || 'Added to cart';
        // refresh cart UI if available
        if (typeof refreshCartDrawer === 'function') {
          try { await refreshCartDrawer(); } catch (e) {}
        } else {
          document.dispatchEvent(new CustomEvent('cart:refresh'));
        }
        const bubble = document.querySelector('[data-cart-count]');
        if (bubble) {
          try {
            const cart = await fetch('/cart.js').then((r) => r.json());
            bubble.textContent = String(cart.item_count || 0);
          } catch (e) {}
        }
      } catch (err) {
        if (status) status.textContent = root.dataset.errorLabel || 'Could not add items. Try again.';
      } finally {
        addBtn.disabled = false;
      }
    });
  }



  document.addEventListener('click', async function (e) {
    const btn = e.target.closest('[data-copy-link]');
    if (!btn) return;
    const link = btn.getAttribute('data-link') || window.location.href;
    try {
      await navigator.clipboard.writeText(link);
      btn.textContent = '✓';
      setTimeout(function () { btn.textContent = '🔗'; }, 1500);
    } catch (err) {
      window.prompt('Copy link', link);
    }
  });


  