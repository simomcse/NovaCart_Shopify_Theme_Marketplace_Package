/* NovaCart module source: 04-collection.js
   Loaded as part of novacart-app.js — edit here then rebuild, or edit novacart-app.js directly.
*/
/* ---------- Collection: view mode + quick add ---------- */
  function initCollectionViewToggle() {
    const grid = document.querySelector('[data-collection-grid]');
    const toggle = document.querySelector('[data-view-toggle]');
    if (!grid || !toggle) return;
    const key = 'novacart_collection_view';
    let mode = 'grid';
    try { mode = localStorage.getItem(key) || 'grid'; } catch (e) {}
    function apply(view) {
      grid.classList.toggle('is-list-view', view === 'list');
      toggle.querySelectorAll('[data-view]').forEach((btn) => {
        const on = btn.getAttribute('data-view') === view;
        btn.classList.toggle('is-active', on);
        btn.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      try { localStorage.setItem(key, view); } catch (e) {}
    }
    apply(mode);
    toggle.querySelectorAll('[data-view]').forEach((btn) => {
      btn.addEventListener('click', () => apply(btn.getAttribute('data-view')));
    });
  }

  function initQuickAdd() {
    document.querySelectorAll('[data-quick-add]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        if (btn.getAttribute('data-has-options') === 'true') {
          const url = btn.getAttribute('data-product-url');
          if (url) window.location.href = url;
          return;
        }
        const id = btn.getAttribute('data-variant-id');
        if (!id) return;
        const original = btn.textContent;
        btn.disabled = true;
        btn.textContent = '…';
        try {
          const res = await fetch('/cart/add.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
            body: JSON.stringify({ id: Number(id), quantity: 1 })
          });
          if (!res.ok) throw new Error('add failed');
          btn.textContent = '✓';
          try {
            const cart = await fetch('/cart.js').then((r) => r.json());
            document.querySelectorAll('[data-cart-count]').forEach((el) => {
              el.textContent = String(cart.item_count || 0);
            });
          } catch (e) {}
          document.dispatchEvent(new CustomEvent('cart:refresh'));
          setTimeout(() => { btn.textContent = original; btn.disabled = false; }, 1200);
        } catch (err) {
          btn.textContent = original;
          btn.disabled = false;
          alert('Could not add to cart');
        }
      });
    });
  }



  function initProductCategoryTabs() {
    document.querySelectorAll('[data-product-cat-tabs]').forEach((tabs) => {
      const section = tabs.closest('[data-products-showcase]') || tabs.parentElement;
      const cards = section.querySelectorAll('[data-product-category]');
      tabs.querySelectorAll('[data-cat-filter]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const filter = (btn.getAttribute('data-cat-filter') || 'all').toLowerCase();
          tabs.querySelectorAll('[data-cat-filter]').forEach((b) => {
            const on = b === btn;
            b.classList.toggle('is-active', on);
            b.setAttribute('aria-selected', on ? 'true' : 'false');
          });
          cards.forEach((card) => {
            const cat = (card.getAttribute('data-product-category') || '').toLowerCase();
            const show = filter === 'all' || cat === filter || cat.indexOf(filter) !== -1;
            card.classList.toggle('is-cat-hidden', !show);
          });
        });
      });
    });
  }

  