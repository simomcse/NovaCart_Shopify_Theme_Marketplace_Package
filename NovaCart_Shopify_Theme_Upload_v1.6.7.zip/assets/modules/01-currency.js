/* NovaCart module source: 01-currency.js
   Loaded as part of novacart-app.js — edit here then rebuild, or edit novacart-app.js directly.
*/
/* ---------- Display currency switcher (USD default) ---------- */
  const CURRENCY_KEY = 'novacart_display_currency';
  const CURRENCY_META = {
    USD: { symbol: '$', code: 'USD', locale: 'en-US' },
    EUR: { symbol: '€', code: 'EUR', locale: 'de-DE' },
    GBP: { symbol: '£', code: 'GBP', locale: 'en-GB' },
    MAD: { symbol: 'د.م.', code: 'MAD', locale: 'ar-MA' }
  };

  function buildRatesFromSelects() {
    const rates = {};
    document.querySelectorAll('[data-currency-switcher] option').forEach((opt) => {
      const code = String(opt.value || '').toUpperCase();
      if (!code) return;
      const rate = parseFloat(opt.getAttribute('data-rate') || '1');
      rates[code] = isFinite(rate) ? rate : 1;
      if (opt.getAttribute('data-symbol')) {
        CURRENCY_META[code] = CURRENCY_META[code] || {
          symbol: opt.getAttribute('data-symbol') || code,
          code: code,
          locale: 'en-US'
        };
        CURRENCY_META[code].symbol = opt.getAttribute('data-symbol') || CURRENCY_META[code].symbol;
        CURRENCY_META[code].code = code;
      }
    });
    return rates;
  }

  function readCurrencyConfig() {
    const html = document.documentElement;
    const fromSelects = buildRatesFromSelects();
    const rates = Object.assign({
      USD: parseFloat(html.getAttribute('data-rate-usd') || '0.10') || 0.10,
      EUR: parseFloat(html.getAttribute('data-rate-eur') || '0.09') || 0.09,
      GBP: parseFloat(html.getAttribute('data-rate-gbp') || '0.08') || 0.08,
      MAD: parseFloat(html.getAttribute('data-rate-mad') || '1') || 1
    }, fromSelects);
    // Default = first option marked selected, else theme setting, else USD
    let defaultCurrency = (html.getAttribute('data-default-currency') || 'USD').toUpperCase();
    const selectedOpt = document.querySelector('[data-currency-switcher] option[selected], [data-currency-switcher] option:checked');
    if (selectedOpt && selectedOpt.value) defaultCurrency = String(selectedOpt.value).toUpperCase();
    return {
      shopCurrency: (html.getAttribute('data-shop-currency') || 'MAD').toUpperCase(),
      defaultCurrency: defaultCurrency,
      rates: rates
    };
  }

  function getSelectedCurrency() {
    try {
      const saved = (localStorage.getItem(CURRENCY_KEY) || '').toUpperCase();
      if (CURRENCY_META[saved]) return saved;
    } catch (e) {}
    return readCurrencyConfig().defaultCurrency || 'USD';
  }

  function setSelectedCurrency(code) {
    code = String(code || 'USD').toUpperCase();
    if (!CURRENCY_META[code]) code = 'USD';
    try { localStorage.setItem(CURRENCY_KEY, code); } catch (e) {}
    return code;
  }

  function shopAmountToTarget(amountInShopCurrency, targetCode) {
    const cfg = readCurrencyConfig();
    const shop = cfg.shopCurrency;
    const target = (targetCode || getSelectedCurrency()).toUpperCase();
    // rates are: 1 shop unit -> X target units
    if (target === shop) return Number(amountInShopCurrency) || 0;
    const rate = cfg.rates[target];
    if (!rate || !isFinite(rate)) return Number(amountInShopCurrency) || 0;
    // If shop is already USD and rate_to_usd is for MAD shop, handle identity
    if (shop === target) return Number(amountInShopCurrency) || 0;
    return (Number(amountInShopCurrency) || 0) * rate;
  }

  function formatDisplayMoney(amountInShopCurrency, targetCode) {
    const code = (targetCode || getSelectedCurrency()).toUpperCase();
    const meta = CURRENCY_META[code] || CURRENCY_META.USD;
    const converted = shopAmountToTarget(amountInShopCurrency, code);
    try {
      return new Intl.NumberFormat(meta.locale, { style: 'currency', currency: meta.code, minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(converted);
    } catch (e) {
      return meta.symbol + converted.toFixed(2);
    }
  }

  function parseMoneyTextToNumber(text) {
    if (!text) return null;
    const cleaned = String(text).replace(/[^\d.,-]/g, '').trim();
    if (!cleaned) return null;
    // Prefer last comma/dot as decimal separator
    let normalized = cleaned;
    if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
      if (cleaned.lastIndexOf(',') > cleaned.lastIndexOf('.')) {
        normalized = cleaned.replace(/\./g, '').replace(',', '.');
      } else {
        normalized = cleaned.replace(/,/g, '');
      }
    } else if (cleaned.indexOf(',') > -1) {
      normalized = cleaned.replace(',', '.');
    }
    const n = parseFloat(normalized);
    return isFinite(n) ? n : null;
  }

  function captureOriginalPrices(root) {
    const scope = root || document;
    const nodes = scope.querySelectorAll('.product-price span, .product-price s, [data-cart-subtotal], [data-line-price], .search-suggest-price, .cart-item-price, [data-product-price], [data-sticky-product-price]');
    nodes.forEach((el) => {
      if (el.getAttribute('data-money-original')) return;
      const n = parseMoneyTextToNumber(el.textContent);
      if (n === null) return;
      el.setAttribute('data-money-original', String(n));
    });
  }

  function applyDisplayCurrency(code) {
    const selected = setSelectedCurrency(code || getSelectedCurrency());
    document.querySelectorAll('[data-currency-switcher]').forEach((sel) => {
      if (sel.value !== selected) sel.value = selected;
    });
    captureOriginalPrices(document);
    document.querySelectorAll('[data-money-original]').forEach((el) => {
      const original = parseFloat(el.getAttribute('data-money-original'));
      if (!isFinite(original)) return;
      el.textContent = formatDisplayMoney(original, selected);
    });
  }

  function initCurrencySwitcher() {
    const selected = getSelectedCurrency();
    document.querySelectorAll('[data-currency-switcher]').forEach((sel) => {
      sel.value = selected;
      sel.addEventListener('change', function () {
        applyDisplayCurrency(sel.value);
      });
    });
    applyDisplayCurrency(selected);
    // Re-apply after dynamic cart/search updates
    const observer = new MutationObserver(function () {
      window.clearTimeout(window.__novacartCurrencyTimer);
      window.__novacartCurrencyTimer = window.setTimeout(function () {
        captureOriginalPrices(document);
        applyDisplayCurrency(getSelectedCurrency());
      }, 80);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  document.addEventListener('DOMContentLoaded', initCurrencySwitcher);
  if (document.readyState !== 'loading') initCurrencySwitcher();



  function getFreeShippingThreshold() {
    var el = document.querySelector('[data-customize-free-shipping-threshold]');
    if (el) {
      var n = parseInt(el.getAttribute('data-customize-free-shipping-threshold'), 10);
      if (isFinite(n)) return n;
    }
    return null;
  }


  