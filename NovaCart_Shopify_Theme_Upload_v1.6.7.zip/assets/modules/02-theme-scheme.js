/* NovaCart module source: 02-theme-scheme.js
   Loaded as part of novacart-app.js — edit here then rebuild, or edit novacart-app.js directly.
*/
/* ---------- Storefront theme color switcher ---------- */
  const THEME_KEY = 'novacart_color_scheme';
  const THEME_SCHEMES = {
    classic: {
      '--color-primary': '#0f172a',
      '--color-secondary': '#2563eb',
      '--color-accent': '#059669',
      '--color-danger': '#dc2626',
      '--color-text': '#0f172a',
      '--color-text-secondary': '#475569',
      '--color-text-muted': '#94a3b8',
      '--color-bg': '#ffffff',
      '--color-bg-soft': '#f8fafc',
      '--color-bg-muted': '#f1f5f9',
      '--color-border': '#e2e8f0',
      '--color-border-strong': '#cbd5e1',
      '--color-header-bg': 'rgba(255, 255, 255, 0.92)',
      '--color-card-bg': '#ffffff'
    },
    dark: {
      '--color-primary': '#e2e8f0',
      '--color-secondary': '#60a5fa',
      '--color-accent': '#34d399',
      '--color-danger': '#f87171',
      '--color-text': '#f1f5f9',
      '--color-text-secondary': '#cbd5e1',
      '--color-text-muted': '#94a3b8',
      '--color-bg': '#0b1220',
      '--color-bg-soft': '#111827',
      '--color-bg-muted': '#1e293b',
      '--color-border': '#334155',
      '--color-border-strong': '#475569',
      '--color-header-bg': 'rgba(11, 18, 32, 0.92)',
      '--color-card-bg': '#111827'
    },
    emerald: {
      '--color-primary': '#064e3b',
      '--color-secondary': '#059669',
      '--color-accent': '#d4a017',
      '--color-danger': '#dc2626',
      '--color-text': '#06281f',
      '--color-text-secondary': '#365f4f',
      '--color-text-muted': '#6b8f7f',
      '--color-bg': '#f6fbf8',
      '--color-bg-soft': '#ecf8f1',
      '--color-bg-muted': '#d9f0e4',
      '--color-border': '#c5e4d4',
      '--color-border-strong': '#9ccfb8',
      '--color-header-bg': 'rgba(246, 251, 248, 0.94)',
      '--color-card-bg': '#ffffff'
    },
    rose: {
      '--color-primary': '#4a1528',
      '--color-secondary': '#be185d',
      '--color-accent': '#c9a227',
      '--color-danger': '#e11d48',
      '--color-text': '#3f0d20',
      '--color-text-secondary': '#6b3048',
      '--color-text-muted': '#a06b80',
      '--color-bg': '#fff8fa',
      '--color-bg-soft': '#fff0f4',
      '--color-bg-muted': '#fde4ec',
      '--color-border': '#f5c6d4',
      '--color-border-strong': '#e8a0b5',
      '--color-header-bg': 'rgba(255, 248, 250, 0.94)',
      '--color-card-bg': '#ffffff'
    },
    royal: {
      '--color-primary': '#1e1b4b',
      '--color-secondary': '#7c3aed',
      '--color-accent': '#f59e0b',
      '--color-danger': '#dc2626',
      '--color-text': '#1e1b4b',
      '--color-text-secondary': '#4c1d95',
      '--color-text-muted': '#8b5cf6',
      '--color-bg': '#faf8ff',
      '--color-bg-soft': '#f3efff',
      '--color-bg-muted': '#e9e0ff',
      '--color-border': '#ddd6fe',
      '--color-border-strong': '#c4b5fd',
      '--color-header-bg': 'rgba(250, 248, 255, 0.94)',
      '--color-card-bg': '#ffffff'
    }
  };

  function getSavedThemeScheme() {
    try {
      const saved = localStorage.getItem(THEME_KEY);
      if (saved && THEME_SCHEMES[saved]) return saved;
    } catch (e) {}
    return 'classic';
  }

  function applyThemeScheme(scheme) {
    scheme = THEME_SCHEMES[scheme] ? scheme : 'classic';
    const vars = THEME_SCHEMES[scheme];
    const root = document.documentElement;
    Object.keys(vars).forEach(function (key) {
      root.style.setProperty(key, vars[key]);
    });
    if (document.body) {
      document.body.className = (document.body.className || '').replace(/\bscheme-[a-z]+\b/g, '').replace(/\s+/g, ' ').trim();
      document.body.classList.add('scheme-' + scheme);
    }
    try { localStorage.setItem(THEME_KEY, scheme); } catch (e) {}
    document.querySelectorAll('[data-theme-switcher]').forEach(function (sel) {
      if (sel.value !== scheme) sel.value = scheme;
    });
  }

  function initThemeSwitcher() {
    const scheme = getSavedThemeScheme();
    applyThemeScheme(scheme);
    document.querySelectorAll('[data-theme-switcher]').forEach(function (sel) {
      sel.value = scheme;
      sel.addEventListener('change', function () {
        applyThemeScheme(sel.value);
      });
    });
  }

  