(function () {
  'use strict';
const rootPath = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || '/';
  const moneyFormatFallback = '${{amount}}';
  function money(cents, format) {
    try {
      const amount = Number(cents || 0) / 100;
      return formatDisplayMoney(amount, getSelectedCurrency());
    } catch (e) {}
    if (window.Shopify && typeof window.Shopify.formatMoney === 'function') {
      return window.Shopify.formatMoney(cents, format || moneyFormatFallback);
    }
    const value = (Number(cents || 0) / 100).toFixed(2);
    return '$' + value;
  }
  const CURRENCY_KEY = 'novacart_display_currency';
  const CURRENCY_META = {
    USD: { symbol: '$', code: 'USD', locale: 'en-US' },
    EUR: { symbol: '€', code: 'EUR', locale: 'de-DE' },
    GBP: { symbol: '£', code: 'GBP', locale: 'en-GB' },
    MAD: { symbol: 'د.م.', code: 'MAD', locale: 'ar-MA' }
  };
  function buildRatesFromSelects() {
    const rates = {};
    document.querySelectorAll('[data-currency-switcher] option').forEach((opt) => {
      const code = String(opt.value || '').toUpperCase();
      if (!code) return;
      const rate = parseFloat(opt.getAttribute('data-rate') || '1');
      rates[code] = isFinite(rate) ? rate : 1;
      if (opt.getAttribute('data-symbol')) {
        CURRENCY_META[code] = CURRENCY_META[code] || {
          symbol: opt.getAttribute('data-symbol') || code,
          code: code,
          locale: 'en-US'
        };
        CURRENCY_META[code].symbol = opt.getAttribute('data-symbol') || CURRENCY_META[code].symbol;
        CURRENCY_META[code].code = code;
      }
    });
    return rates;
  }
  function readCurrencyConfig() {
    const html = document.documentElement;
    const fromSelects = buildRatesFromSelects();
    const rates = Object.assign({
      USD: parseFloat(html.getAttribute('data-rate-usd') || '0.10') || 0.10,
      EUR: parseFloat(html.getAttribute('data-rate-eur') || '0.09') || 0.09,
      GBP: parseFloat(html.getAttribute('data-rate-gbp') || '0.08') || 0.08,
      MAD: parseFloat(html.getAttribute('data-rate-mad') || '1') || 1
    }, fromSelects);
    let defaultCurrency = (html.getAttribute('data-default-currency') || 'USD').toUpperCase();
    const selectedOpt = document.querySelector('[data-currency-switcher] option[selected], [data-currency-switcher] option:checked');
    if (selectedOpt && selectedOpt.value) defaultCurrency = String(selectedOpt.value).toUpperCase();
    return {
      shopCurrency: (html.getAttribute('data-shop-currency') || 'MAD').toUpperCase(),
      defaultCurrency: defaultCurrency,
      rates: rates
    };
  }
  function getSelectedCurrency() {
    try {
      const saved = (localStorage.getItem(CURRENCY_KEY) || '').toUpperCase();
      if (CURRENCY_META[saved]) return saved;
    } catch (e) {}
    return readCurrencyConfig().defaultCurrency || 'USD';
  }
  function setSelectedCurrency(code) {
    code = String(code || 'USD').toUpperCase();
    if (!CURRENCY_META[code]) code = 'USD';
    try { localStorage.setItem(CURRENCY_KEY, code); } catch (e) {}
    return code;
  }
  function shopAmountToTarget(amountInShopCurrency, targetCode) {
    const cfg = readCurrencyConfig();
    const shop = cfg.shopCurrency;
    const target = (targetCode || getSelectedCurrency()).toUpperCase();
    if (target === shop) return Number(amountInShopCurrency) || 0;
    const rate = cfg.rates[target];
    if (!rate || !isFinite(rate)) return Number(amountInShopCurrency) || 0;
    if (shop === target) return Number(amountInShopCurrency) || 0;
    return (Number(amountInShopCurrency) || 0) * rate;
  }
  function formatDisplayMoney(amountInShopCurrency, targetCode) {
    const code = (targetCode || getSelectedCurrency()).toUpperCase();
    const meta = CURRENCY_META[code] || CURRENCY_META.USD;
    const converted = shopAmountToTarget(amountInShopCurrency, code);
    try {
      return new Intl.NumberFormat(meta.locale, { style: 'currency', currency: meta.code, minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(converted);
    } catch (e) {
      return meta.symbol + converted.toFixed(2);
    }
  }
  function parseMoneyTextToNumber(text) {
    if (!text) return null;
    const cleaned = String(text).replace(/[^\d.,-]/g, '').trim();
    if (!cleaned) return null;
    let normalized = cleaned;
    if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
      if (cleaned.lastIndexOf(',') > cleaned.lastIndexOf('.')) {
        normalized = cleaned.replace(/\./g, '').replace(',', '.');
      } else {
        normalized = cleaned.replace(/,/g, '');
      }
    } else if (cleaned.indexOf(',') > -1) {
      normalized = cleaned.replace(',', '.');
    }
    const n = parseFloat(normalized);
    return isFinite(n) ? n : null;
  }
  function captureOriginalPrices(root) {
    const scope = root || document;
    const nodes = scope.querySelectorAll('.product-price span, .product-price s, [data-cart-subtotal], [data-line-price], .search-suggest-price, .cart-item-price, [data-product-price], [data-sticky-product-price]');
    nodes.forEach((el) => {
      if (el.getAttribute('data-money-original')) return;
      const n = parseMoneyTextToNumber(el.textContent);
      if (n === null) return;
      el.setAttribute('data-money-original', String(n));
    });
  }
  function applyDisplayCurrency(code) {
    const selected = setSelectedCurrency(code || getSelectedCurrency());
    document.querySelectorAll('[data-currency-switcher]').forEach((sel) => {
      if (sel.value !== selected) sel.value = selected;
    });
    captureOriginalPrices(document);
    document.querySelectorAll('[data-money-original]').forEach((el) => {
      const original = parseFloat(el.getAttribute('data-money-original'));
      if (!isFinite(original)) return;
      el.textContent = formatDisplayMoney(original, selected);
    });
  }
  function initCurrencySwitcher() {
    const selected = getSelectedCurrency();
    document.querySelectorAll('[data-currency-switcher]').forEach((sel) => {
      sel.value = selected;
      sel.addEventListener('change', function () {
        applyDisplayCurrency(sel.value);
      });
    });
    applyDisplayCurrency(selected);
    const observer = new MutationObserver(function () {
      window.clearTimeout(window.__novacartCurrencyTimer);
      window.__novacartCurrencyTimer = window.setTimeout(function () {
        captureOriginalPrices(document);
        applyDisplayCurrency(getSelectedCurrency());
      }, 80);
    });
    observer.observe(document.getElementById('MainContent') || document.body, { childList: true, subtree: true });
  }
  document.addEventListener('DOMContentLoaded', initCurrencySwitcher);
  if (document.readyState !== 'loading') initCurrencySwitcher();
  function getFreeShippingThreshold() {
    var el = document.querySelector('[data-customize-free-shipping-threshold]');
    if (el) {
      var n = parseInt(el.getAttribute('data-customize-free-shipping-threshold'), 10);
      if (isFinite(n)) return n;
    }
    return null;
  }
  const THEME_KEY = 'novacart_color_scheme';
  const THEME_SCHEMES = {
    classic: {
      '--color-primary': '#0f172a',
      '--color-secondary': '#2563eb',
      '--color-accent': '#059669',
      '--color-danger': '#dc2626',
      '--color-text': '#0f172a',
      '--color-text-secondary': '#475569',
      '--color-text-muted': '#94a3b8',
      '--color-bg': '#ffffff',
      '--color-bg-soft': '#f8fafc',
      '--color-bg-muted': '#f1f5f9',
      '--color-border': '#e2e8f0',
      '--color-border-strong': '#cbd5e1',
      '--color-header-bg': 'rgba(255, 255, 255, 0.92)',
      '--color-card-bg': '#ffffff'
    },
    dark: {
      '--color-primary': '#e2e8f0',
      '--color-secondary': '#60a5fa',
      '--color-accent': '#34d399',
      '--color-danger': '#f87171',
      '--color-text': '#f1f5f9',
      '--color-text-secondary': '#cbd5e1',
      '--color-text-muted': '#94a3b8',
      '--color-bg': '#0b1220',
      '--color-bg-soft': '#111827',
      '--color-bg-muted': '#1e293b',
      '--color-border': '#334155',
      '--color-border-strong': '#475569',
      '--color-header-bg': 'rgba(11, 18, 32, 0.92)',
      '--color-card-bg': '#111827'
    },
    emerald: {
      '--color-primary': '#064e3b',
      '--color-secondary': '#059669',
      '--color-accent': '#d4a017',
      '--color-danger': '#dc2626',
      '--color-text': '#06281f',
      '--color-text-secondary': '#365f4f',
      '--color-text-muted': '#6b8f7f',
      '--color-bg': '#f6fbf8',
      '--color-bg-soft': '#ecf8f1',
      '--color-bg-muted': '#d9f0e4',
      '--color-border': '#c5e4d4',
      '--color-border-strong': '#9ccfb8',
      '--color-header-bg': 'rgba(246, 251, 248, 0.94)',
      '--color-card-bg': '#ffffff'
    },
    rose: {
      '--color-primary': '#4a1528',
      '--color-secondary': '#be185d',
      '--color-accent': '#c9a227',
      '--color-danger': '#e11d48',
      '--color-text': '#3f0d20',
      '--color-text-secondary': '#6b3048',
      '--color-text-muted': '#a06b80',
      '--color-bg': '#fff8fa',
      '--color-bg-soft': '#fff0f4',
      '--color-bg-muted': '#fde4ec',
      '--color-border': '#f5c6d4',
      '--color-border-strong': '#e8a0b5',
      '--color-header-bg': 'rgba(255, 248, 250, 0.94)',
      '--color-card-bg': '#ffffff'
    },
    royal: {
      '--color-primary': '#1e1b4b',
      '--color-secondary': '#7c3aed',
      '--color-accent': '#f59e0b',
      '--color-danger': '#dc2626',
      '--color-text': '#1e1b4b',
      '--color-text-secondary': '#4c1d95',
      '--color-text-muted': '#8b5cf6',
      '--color-bg': '#faf8ff',
      '--color-bg-soft': '#f3efff',
      '--color-bg-muted': '#e9e0ff',
      '--color-border': '#ddd6fe',
      '--color-border-strong': '#c4b5fd',
      '--color-header-bg': 'rgba(250, 248, 255, 0.94)',
      '--color-card-bg': '#ffffff'
    }
  };
  function getSavedThemeScheme() {
    try {
      const saved = localStorage.getItem(THEME_KEY);
      if (saved && THEME_SCHEMES[saved]) return saved;
    } catch (e) {}
    return 'classic';
  }
  function applyThemeScheme(scheme) {
    scheme = THEME_SCHEMES[scheme] ? scheme : 'classic';
    const vars = THEME_SCHEMES[scheme];
    const root = document.documentElement;
    Object.keys(vars).forEach(function (key) {
      root.style.setProperty(key, vars[key]);
    });
    if (document.body) {
      document.body.className = (document.body.className || '').replace(/\bscheme-[a-z]+\b/g, '').replace(/\s+/g, ' ').trim();
      document.body.classList.add('scheme-' + scheme);
    }
    try { localStorage.setItem(THEME_KEY, scheme); } catch (e) {}
    document.querySelectorAll('[data-theme-switcher]').forEach(function (sel) {
      if (sel.value !== scheme) sel.value = scheme;
    });
  }
  function initThemeSwitcher() {
    const scheme = getSavedThemeScheme();
    applyThemeScheme(scheme);
    document.querySelectorAll('[data-theme-switcher]').forEach(function (sel) {
      sel.value = scheme;
      sel.addEventListener('change', function () {
        applyThemeScheme(sel.value);
      });
    });
  }
  document.addEventListener('DOMContentLoaded', initThemeSwitcher);
  document.addEventListener('DOMContentLoaded', function () { document.documentElement.classList.remove('no-js'); document.documentElement.classList.add('js'); initSizeChart(); initShippingCalculator(); initFbt(); initCollectionViewToggle(); initQuickAdd(); initProductCategoryTabs(); });
  if (document.readyState !== 'loading') initThemeSwitcher();
  document.addEventListener('change', function (e) {
    if (e.target && e.target.id === 'quantity') {
      document.querySelectorAll('[data-product-quantity-sync]').forEach(function (input) {
        input.value = e.target.value || 1;
      });
      var codQty = document.getElementById('cod-quantity');
      if (codQty) codQty.value = e.target.value || 1;
    }
  });
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('[data-qty-delta]');
    if (!btn) return;
    window.setTimeout(function () {
      const q = document.getElementById('quantity');
      if (!q) return;
      document.querySelectorAll('[data-product-quantity-sync]').forEach(function (input) {
        input.value = q.value || 1;
      });
      var codQty = document.getElementById('cod-quantity');
      if (codQty) codQty.value = q.value || 1;
    }, 0);
  });
  function initSizeChart() {
    const dialog = document.querySelector('[data-size-chart-dialog]');
    if (!dialog) return;
    const openBtns = document.querySelectorAll('[data-size-chart-open]');
    const closeBtn = dialog.querySelector('[data-size-chart-close]');
    openBtns.forEach((btn) => btn.addEventListener('click', () => {
      if (typeof dialog.showModal === 'function') dialog.showModal();
      else dialog.setAttribute('open', '');
    }));
    closeBtn?.addEventListener('click', () => {
      if (typeof dialog.close === 'function') dialog.close();
      else dialog.removeAttribute('open');
    });
    dialog.addEventListener('click', (e) => {
      if (e.target === dialog) {
        if (typeof dialog.close === 'function') dialog.close();
        else dialog.removeAttribute('open');
      }
    });
  }
  function initShippingCalculator() {
    document.querySelectorAll('[data-shipping-calculator]').forEach((root) => {
      const select = root.querySelector('[data-ship-country]');
      const result = root.querySelector('[data-ship-result]');
      const btn = root.querySelector('[data-ship-estimate]');
      if (!select || !result || !btn) return;
      btn.addEventListener('click', () => {
        const opt = select.options[select.selectedIndex];
        if (!opt) return;
        const rate = parseFloat(opt.getAttribute('data-rate') || '0');
        const days = opt.getAttribute('data-days') || '';
        const label = opt.getAttribute('data-label') || opt.textContent.trim();
        const zip = (root.querySelector('[data-ship-zip]')?.value || '').trim();
        let text;
        if (!isFinite(rate) || rate <= 0) {
          text = `✓ ${label}: Free shipping` + (days ? ` · ${days}` : '');
        } else {
          const formatted = (typeof formatDisplayMoney === 'function')
            ? formatDisplayMoney(rate)
            : (rate.toFixed(2) + ' ' + (document.documentElement.getAttribute('data-default-currency') || 'USD'));
          text = `✓ ${label}: ${formatted}` + (days ? ` · ${days}` : '');
        }
        if (zip) text += ` · ZIP ${zip}`;
        result.hidden = false;
        result.textContent = text;
      });
    });
  }
  function initFbt() {
    const root = document.querySelector('[data-fbt]');
    if (!root) return;
    const totalEl = root.querySelector('[data-fbt-total]');
    const status = root.querySelector('[data-fbt-status]');
    const addBtn = root.querySelector('[data-fbt-add]');
    const moneyFormat = totalEl?.getAttribute('data-money-format') || '';
    function selectedItems() {
      return Array.from(root.querySelectorAll('[data-fbt-main], [data-fbt-item]')).filter((el) => el.checked);
    }
    function updateTotal() {
      if (!totalEl) return;
      let cents = 0;
      selectedItems().forEach((el) => {
        cents += parseInt(el.getAttribute('data-price') || '0', 10) || 0;
      });
      if (typeof money === 'function') {
        totalEl.textContent = money(cents, moneyFormat);
      } else {
        totalEl.textContent = (cents / 100).toFixed(2);
      }
      if (typeof applyCurrencyConversion === 'function') {
        try { applyCurrencyConversion(); } catch (e) {}
      }
    }
    root.querySelectorAll('[data-fbt-item]').forEach((el) => {
      el.addEventListener('change', updateTotal);
    });
    updateTotal();
    addBtn?.addEventListener('click', async () => {
      const items = selectedItems().map((el) => ({
        id: Number(el.value),
        quantity: 1
      })).filter((item) => item.id);
      if (!items.length) return;
      addBtn.disabled = true;
      if (status) {
        status.hidden = false;
        status.textContent = '…';
      }
      try {
        const res = await fetch('/cart/add.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify({ items })
        });
        if (!res.ok) throw new Error('add failed');
        if (status) status.textContent = root.dataset.successLabel || 'Added to cart';
        if (typeof refreshCartDrawer === 'function') {
          try { await refreshCartDrawer(); } catch (e) {}
        } else {
          document.dispatchEvent(new CustomEvent('cart:refresh'));
        }
        const bubble = document.querySelector('[data-cart-count]');
        if (bubble) {
          try {
            const cart = await fetch('/cart.js').then((r) => r.json());
            bubble.textContent = String(cart.item_count || 0);
          } catch (e) {}
        }
      } catch (err) {
        if (status) status.textContent = root.dataset.errorLabel || 'Could not add items. Try again.';
      } finally {
        addBtn.disabled = false;
      }
    });
  }
  document.addEventListener('click', async function (e) {
    const btn = e.target.closest('[data-copy-link]');
    if (!btn) return;
    const link = btn.getAttribute('data-link') || window.location.href;
    try {
      await navigator.clipboard.writeText(link);
      btn.textContent = '✓';
      setTimeout(function () { btn.textContent = '🔗'; }, 1500);
    } catch (err) {
      window.prompt('Copy link', link);
    }
  });
  function initCollectionViewToggle() {
    const grid = document.querySelector('[data-collection-grid]');
    const toggle = document.querySelector('[data-view-toggle]');
    if (!grid || !toggle) return;
    const key = 'novacart_collection_view';
    let mode = 'grid';
    try { mode = localStorage.getItem(key) || 'grid'; } catch (e) {}
    function apply(view) {
      grid.classList.toggle('is-list-view', view === 'list');
      toggle.querySelectorAll('[data-view]').forEach((btn) => {
        const on = btn.getAttribute('data-view') === view;
        btn.classList.toggle('is-active', on);
        btn.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      try { localStorage.setItem(key, view); } catch (e) {}
    }
    apply(mode);
    toggle.querySelectorAll('[data-view]').forEach((btn) => {
      btn.addEventListener('click', () => apply(btn.getAttribute('data-view')));
    });
  }
  function initQuickAdd() {
    document.querySelectorAll('[data-quick-add]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        if (btn.getAttribute('data-has-options') === 'true') {
          const url = btn.getAttribute('data-product-url');
          if (url) window.location.href = url;
          return;
        }
        const id = btn.getAttribute('data-variant-id');
        if (!id) return;
        const original = btn.textContent;
        btn.disabled = true;
        btn.textContent = '…';
        try {
          const res = await fetch('/cart/add.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
            body: JSON.stringify({ id: Number(id), quantity: 1 })
          });
          if (!res.ok) throw new Error('add failed');
          btn.textContent = '✓';
          try {
            const cart = await fetch('/cart.js').then((r) => r.json());
            document.querySelectorAll('[data-cart-count]').forEach((el) => {
              el.textContent = String(cart.item_count || 0);
            });
          } catch (e) {}
          document.dispatchEvent(new CustomEvent('cart:refresh'));
          setTimeout(() => { btn.textContent = original; btn.disabled = false; }, 1200);
        } catch (err) {
          btn.textContent = original;
          btn.disabled = false;
          alert('Could not add to cart');
        }
      });
    });
  }
  function initProductCategoryTabs() {
    document.querySelectorAll('[data-product-cat-tabs]').forEach((tabs) => {
      const section = tabs.closest('[data-products-showcase]') || tabs.parentElement;
      const cards = section.querySelectorAll('[data-product-category]');
      tabs.querySelectorAll('[data-cat-filter]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const filter = (btn.getAttribute('data-cat-filter') || 'all').toLowerCase();
          tabs.querySelectorAll('[data-cat-filter]').forEach((b) => {
            const on = b === btn;
            b.classList.toggle('is-active', on);
            b.setAttribute('aria-selected', on ? 'true' : 'false');
          });
          cards.forEach((card) => {
            const cat = (card.getAttribute('data-product-category') || '').toLowerCase();
            const show = filter === 'all' || cat === filter || cat.indexOf(filter) !== -1;
            card.classList.toggle('is-cat-hidden', !show);
          });
        });
      });
    });
  }
  function setBodyScroll(locked) {
    document.body.style.overflow = locked ? 'hidden' : '';
  }
  window.openCartDrawer = function () {
    const drawer = document.getElementById('cart-drawer');
    const overlay = document.getElementById('cart-drawer-overlay');
    if (drawer) {
      drawer.classList.add('open');
      drawer.setAttribute('aria-modal', 'true');
      drawer.setAttribute('aria-hidden', 'false');
      drawer.removeAttribute('inert');
    }
    if (overlay) overlay.classList.add('open');
    setBodyScroll(true);
    refreshCartDrawer();
  };
  window.closeCartDrawer = function () {
    const drawer = document.getElementById('cart-drawer');
    const overlay = document.getElementById('cart-drawer-overlay');
    if (drawer) {
      drawer.classList.remove('open');
      drawer.setAttribute('aria-modal', 'false');
      drawer.setAttribute('aria-hidden', 'true');
      drawer.setAttribute('inert', '');
    }
    if (overlay) overlay.classList.remove('open');
    setBodyScroll(false);
  };
  window.openMobileMenu = function () {
    const nav = document.getElementById('mobile-nav');
    const overlay = document.getElementById('mobile-overlay');
    if (nav) nav.classList.add('active');
    if (overlay) overlay.classList.add('active');
    setBodyScroll(true);
  };
  window.closeMobileMenu = function () {
    const nav = document.getElementById('mobile-nav');
    const overlay = document.getElementById('mobile-overlay');
    if (nav) nav.classList.remove('active');
    if (overlay) overlay.classList.remove('active');
    setBodyScroll(false);
  };
  function setQuantity(value) {
    const visible = document.getElementById('quantity');
    const hidden = document.getElementById('cod-quantity');
    let qty = Number.parseInt(value, 10);
    if (!Number.isFinite(qty) || qty < 1) qty = 1;
    if (visible) visible.value = String(qty);
    if (hidden) hidden.value = String(qty);
  }
  function initProduct(root) {
    let variants = [];
    try {
      variants = JSON.parse(root.querySelector('[data-product-variants]')?.textContent || '[]');
    } catch (error) {
      console.error('Unable to parse product variants.', error);
      return;
    }
    if (!variants.length) return;
    const form = root.querySelector('[data-cod-form]');
    const variantId = root.querySelector('#selected-variant-id');
    const qtyInput = root.querySelector('#quantity');
    const qtyHidden = root.querySelector('#cod-quantity');
    const priceEl = root.querySelector('[data-product-price]');
    const compareEl = root.querySelector('[data-product-compare]');
    const saleBadge = root.querySelector('[data-product-sale-badge]');
    const availability = root.querySelector('[data-product-availability]');
    const submit = root.querySelector('[data-cod-submit]');
    const errorEl = root.querySelector('[data-cod-error]');
    const moneyFormat = root.dataset.moneyFormat;
    function selectedOptions() {
      return Array.from(root.querySelectorAll('.variant-group')).map((group) => {
        return group.querySelector('.variant-option.selected')?.dataset.value;
      });
    }
    function findVariant() {
      const selected = selectedOptions();
      return variants.find((variant) => variant.options.every((option, index) => option === selected[index])) || null;
    }
    function refreshOptionAvailability(selectedVariant) {
      root.querySelectorAll('.variant-group').forEach((group) => {
        const index = Number(group.dataset.optionIndex);
        group.querySelectorAll('.variant-option').forEach((button) => {
          const possible = variants.some((variant) => {
            if (!variant.available || variant.options[index] !== button.dataset.value) return false;
            return variant.options.every((option, optionIndex) => {
              if (optionIndex === index) return true;
              const selected = selectedOptions()[optionIndex];
              return !selected || option === selected;
            });
          });
          button.classList.toggle('disabled', !possible);
          button.setAttribute('aria-disabled', possible ? 'false' : 'true');
        });
      });
      if (selectedVariant) {
        root.querySelectorAll('.variant-option.selected').forEach((button) => {
          button.setAttribute('aria-pressed', 'true');
        });
      }
    }
    function updateVariant() {
      const match = findVariant();
      if (!match) {
        if (submit) submit.disabled = true;
        if (availability) availability.textContent = root.dataset.unavailableLabel || 'Unavailable';
        return;
      }
      if (variantId) variantId.value = String(match.id);
      root.querySelectorAll('[data-product-variant-id]').forEach(function (input) {
        input.value = String(match.id);
      });
      if (priceEl) {
        priceEl.textContent = money(match.price, moneyFormat);
        priceEl.setAttribute('data-money-original', String(Number(match.price) / 100));
      }
      const onSale = match.compare_at_price && match.compare_at_price > match.price;
      if (compareEl) {
        compareEl.textContent = onSale ? money(match.compare_at_price, moneyFormat) : '';
        compareEl.hidden = !onSale;
        if (onSale) compareEl.setAttribute('data-money-original', String(Number(match.compare_at_price) / 100));
      }
      if (saleBadge) saleBadge.hidden = !onSale;
      if (availability) availability.textContent = match.available ? (root.dataset.stockLabel || 'In stock') : (root.dataset.soldOutLabel || 'Sold out');
      if (submit) submit.disabled = !match.available;
      root.querySelectorAll('[data-add-to-cart]').forEach(function (btn) {
        btn.disabled = !match.available;
      });
      if (match.featured_image && match.featured_image.src) {
        const mainImage = root.querySelector('#MainProductImage');
        if (mainImage) {
          let imageChanged = true;
          try { imageChanged = new URL(mainImage.src, window.location.href).pathname !== new URL(match.featured_image.src, window.location.href).pathname; } catch (_) {}
          if (imageChanged) { mainImage.src = match.featured_image.src; mainImage.removeAttribute('srcset'); }
        }
      }
      try {
        const url = new URL(window.location.href);
        url.searchParams.set('variant', match.id);
        window.history.replaceState({}, '', url.toString());
      } catch (_) {}
      refreshOptionAvailability(match);
    }
    root.querySelectorAll('.variant-option').forEach((button) => {
      button.addEventListener('click', function () {
        if (this.getAttribute('aria-disabled') === 'true' || this.classList.contains('disabled')) return;
        const group = this.closest('.variant-group');
        if (!group) return;
        group.querySelectorAll('.variant-option').forEach((option) => {
          option.classList.remove('selected');
          option.setAttribute('aria-pressed', 'false');
        });
        this.classList.add('selected');
        this.setAttribute('aria-pressed', 'true');
        const changedIndex = Number(group.dataset.optionIndex);
        const selected = selectedOptions();
        const matchingVariants = variants.filter((variant) => variant.available && variant.options[changedIndex] === this.dataset.value);
        const exactMatch = matchingVariants.find((variant) => variant.options.every((option, index) => index === changedIndex || !selected[index] || option === selected[index]));
        const fallbackMatch = exactMatch || matchingVariants[0];
        if (fallbackMatch) {
          root.querySelectorAll('.variant-group').forEach((optionGroup, index) => {
            if (index === changedIndex) return;
            const selectedButton = Array.from(optionGroup.querySelectorAll('.variant-option')).find((option) => option.dataset.value === fallbackMatch.options[index]);
            if (!selectedButton) return;
            optionGroup.querySelectorAll('.variant-option').forEach((option) => {
              const active = option === selectedButton;
              option.classList.toggle('selected', active);
              option.setAttribute('aria-pressed', active ? 'true' : 'false');
            });
          });
        }
        updateVariant();
      });
    });
    root.querySelectorAll('[data-image-src]').forEach((button) => {
      button.addEventListener('click', function () {
        const main = root.querySelector('#MainProductImage');
        if (main) { main.src = this.dataset.imageSrc; main.removeAttribute('srcset'); }
        root.querySelectorAll('[data-image-src]').forEach((other) => {
          other.classList.toggle('active', other === this);
          other.setAttribute('aria-pressed', other === this ? 'true' : 'false');
        });
      });
    });
    root.querySelectorAll('[data-qty-delta]').forEach((button) => {
      button.addEventListener('click', () => setQuantity((Number.parseInt(qtyInput?.value || '1', 10) || 1) + Number(button.dataset.qtyDelta)));
    });
    if (qtyInput) {
      qtyInput.addEventListener('input', () => setQuantity(qtyInput.value));
      qtyInput.addEventListener('change', () => setQuantity(qtyInput.value));
    }
    if (qtyHidden && qtyInput) qtyHidden.value = qtyInput.value || '1';
    if (form) {
      form.addEventListener('submit', async function (event) {
        if (!window.fetch || !window.URLSearchParams) return; // Native Shopify form fallback.
        event.preventDefault();
        if (!form.reportValidity()) return;
        if (errorEl) { errorEl.hidden = true; errorEl.textContent = ''; }
        if (submit) { submit.disabled = true; submit.dataset.originalText = submit.textContent; submit.textContent = root.dataset.processingLabel || 'Processing…'; }
        const attributes = {
          'COD customer name': form.querySelector('#cod-name')?.value.trim() || '',
          'COD customer phone': form.querySelector('#cod-phone')?.value.trim() || '',
          'COD customer city': form.querySelector('#cod-city')?.value.trim() || '',
          'COD customer address': form.querySelector('#cod-address')?.value.trim() || ''
        };
        const payload = new URLSearchParams();
        payload.set('id', variantId?.value || '');
        payload.set('quantity', String(Math.max(1, Number.parseInt(qtyInput?.value || '1', 10) || 1)));
        let originalAttributes = null;
        try {
          const cartResponse = await fetch(rootPath + 'cart.js', {
            headers: { 'Accept': 'application/json' }
          });
          if (!cartResponse.ok) throw new Error(root.dataset.saveError || 'Could not read the current cart. Please try again.');
          const cartBefore = await cartResponse.json();
          originalAttributes = cartBefore.attributes || {};
          const updateResponse = await fetch(rootPath + 'cart/update.js', {
            method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ attributes })
          });
          if (!updateResponse.ok) throw new Error(root.dataset.saveError || 'Could not save the order details. Please try again.');
          const addResponse = await fetch(rootPath + 'cart/add.js', {
            method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Accept': 'application/json' },
            body: payload.toString()
          });
          const result = await addResponse.json();
          if (!addResponse.ok) throw new Error(result.description || result.message || root.dataset.addError || 'Could not add this item to your cart.');
          window.location.assign(rootPath + 'checkout');
        } catch (error) {
          if (originalAttributes !== null) {
            try {
              await fetch(rootPath + 'cart/update.js', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                body: JSON.stringify({ attributes: originalAttributes })
              });
            } catch (_) {  }
          }
          if (errorEl) {
            errorEl.textContent = error.message || root.dataset.addError || 'Something went wrong. Please try again.';
            errorEl.hidden = false;
          }
          if (submit) { submit.disabled = false; submit.textContent = submit.dataset.originalText || 'Continue to checkout'; }
        }
      });
    }
    updateVariant();
  }
  function initQuickView() {
    const dialog = document.querySelector('[data-quick-view-dialog]');
    const content = document.querySelector('[data-quick-view-content]');
    if (!dialog || !content) return;
    const close = () => { if (dialog.open) dialog.close(); };
    dialog.querySelector('[data-quick-view-close]')?.addEventListener('click', close);
    dialog.addEventListener('click', (event) => { if (event.target === dialog) close(); });
    document.querySelectorAll('[data-quick-view]').forEach((trigger) => {
      trigger.addEventListener('click', async () => {
        const handle = trigger.dataset.productHandle;
        if (!handle) return;
        content.textContent = '';
        const loading = document.createElement('p');
        loading.className = 'quick-view-loading';
        loading.setAttribute('role', 'status');
        loading.textContent = dialog.dataset.loadingLabel || 'Loading…';
        content.appendChild(loading);
        if (!dialog.open) dialog.showModal();
        try {
          const response = await fetch(rootPath + 'products/' + encodeURIComponent(handle) + '.js', {
            headers: { Accept: 'application/json' }
          });
          if (!response.ok) throw new Error(dialog.dataset.loadErrorLabel || 'Product could not be loaded.');
          const product = await response.json();
          content.textContent = '';
          const layout = document.createElement('div');
          layout.className = 'quick-view-layout';
          const image = document.createElement('img');
          image.className = 'quick-view-image';
          image.src = product.featured_image || '';
          image.alt = product.title || '';
          image.loading = 'lazy';
          const info = document.createElement('div');
          info.className = 'quick-view-info';
          const title = document.createElement('h2');
          title.id = 'quick-view-title';
          title.textContent = product.title || '';
          const price = document.createElement('p');
          price.className = 'product-price quick-view-price';
          const moneyFormat = (window.Shopify && window.Shopify.money_format) || moneyFormatFallback;
          const priceValue = document.createElement('span');
          priceValue.textContent = money(product.price, moneyFormat);
          price.appendChild(priceValue);
          const link = document.createElement('a');
          link.className = 'btn btn-secondary';
          link.href = trigger.dataset.productUrl || product.url || '#';
          link.textContent = dialog.dataset.viewProductLabel || 'View full details';
          info.append(title, price);
          if (Array.isArray(product.variants) && product.variants.length > 1) {
            const label = document.createElement('label');
            label.textContent = dialog.dataset.selectVariantLabel || 'Choose an option';
            label.htmlFor = 'quick-view-variant';
            const select = document.createElement('select');
            select.id = 'quick-view-variant';
            select.className = 'quick-view-variant';
            product.variants.forEach((variant) => {
              const option = document.createElement('option');
              option.value = variant.id;
              option.textContent = variant.public_title || variant.title;
              option.disabled = !variant.available;
              option.selected = variant.id === (product.variants.find((item) => item.available) || product.variants[0]).id;
              select.appendChild(option);
            });
            info.append(label, select);
          }
          const status = document.createElement('p');
          status.className = 'quick-view-status';
          status.setAttribute('role', 'status');
          const add = document.createElement('button');
          add.type = 'button';
          add.className = 'btn btn-primary';
          add.textContent = dialog.dataset.addToCartLabel || 'Add to cart';
          add.disabled = !product.available;
          add.addEventListener('click', async () => {
            const select = info.querySelector('#quick-view-variant');
            const selectedId = select ? select.value : product.variants[0]?.id;
            if (!selectedId) return;
            add.disabled = true;
            try {
              const addResponse = await fetch(rootPath + 'cart/add.js', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
                body: JSON.stringify({ items: [{ id: Number(selectedId), quantity: 1 }] })
              });
              const result = await addResponse.json();
              if (!addResponse.ok) throw new Error(result.description || result.message || dialog.dataset.addErrorLabel || 'Could not add this product.');
              window.location.assign(rootPath + 'cart');
            } catch (error) {
              status.textContent = error.message || dialog.dataset.addErrorLabel || 'Could not add this product.';
              add.disabled = false;
            }
          });
          info.append(add, link, status);
          if (product.featured_image) layout.appendChild(image);
          layout.appendChild(info);
          content.appendChild(layout);
        } catch (error) {
          content.textContent = error.message || dialog.dataset.loadErrorLabel || 'Product could not be loaded.';
        }
      });
    });
  }
  function initProductEnhancements() {
    document.querySelectorAll('[data-product-root]').forEach((productRoot) => {
      const bar = productRoot.querySelector('[data-sticky-product-bar]');
      const price = productRoot.querySelector('[data-product-price]');
      const stickyPrice = productRoot.querySelector('[data-sticky-product-price]');
      const buy = productRoot.querySelector('[data-sticky-buy]');
      const form = productRoot.querySelector('[data-cod-form]');
      if (bar && buy && form) {
        buy.addEventListener('click', () => {
          const submit = form.querySelector('[data-cod-submit]');
          if (submit && !submit.disabled) {
            form.scrollIntoView({ behavior: 'smooth', block: 'center' });
            window.setTimeout(() => {
              const name = form.querySelector('#cod-name');
              if (name) name.focus({ preventScroll: true });
            }, 350);
          } else {
            form.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        });
        const updateStickyPrice = () => { if (price && stickyPrice) stickyPrice.textContent = price.textContent; };
        updateStickyPrice();
        productRoot.querySelectorAll('.variant-option').forEach((option) => option.addEventListener('click', () => window.setTimeout(updateStickyPrice, 0)));
      }
      const imageButton = productRoot.querySelector('[data-product-image-zoom]');
      const zoomDialog = productRoot.querySelector('[data-image-zoom-dialog]');
      const zoomImage = zoomDialog?.querySelector('[data-zoom-image]');
      const mainImage = productRoot.querySelector('#MainProductImage');
      if (imageButton && zoomDialog && zoomImage && mainImage) {
        imageButton.addEventListener('click', () => {
          zoomImage.src = mainImage.src;
          zoomImage.alt = mainImage.alt;
          if (!zoomDialog.open) zoomDialog.showModal();
        });
        zoomDialog.querySelector('[data-image-zoom-close]')?.addEventListener('click', () => zoomDialog.close());
        zoomDialog.addEventListener('click', (event) => { if (event.target === zoomDialog) zoomDialog.close(); });
        productRoot.querySelectorAll('[data-image-src]').forEach((thumb) => thumb.addEventListener('click', () => {
          zoomImage.src = thumb.dataset.imageSrc || mainImage.src;
        }));
      }
    });
  }
  let cartState = null;
  function updateShippingProgress(cart) {
    document.querySelectorAll('[data-free-shipping]').forEach((bar) => {
      const threshold = Number(
        (typeof getFreeShippingThreshold === 'function' && getFreeShippingThreshold()) ||
        bar.dataset.freeShippingThreshold ||
        bar.closest('[data-cart-drawer]')?.dataset.freeShippingThreshold ||
        0
      );
      if (!threshold) return;
      const total = Number(cart.total_price || 0);
      const progress = Math.max(0, Math.min(100, Math.round((total / threshold) * 100)));
      const progressFill = bar.querySelector('[data-free-shipping-progress]');
      const progressTrack = bar.querySelector('[role="progressbar"]');
      const message = bar.querySelector('[data-free-shipping-message]');
      if (progressFill) progressFill.style.width = `${progress}%`;
      if (progressTrack) progressTrack.setAttribute('aria-valuenow', String(progress));
      if (message) {
        if (total >= threshold) {
          message.textContent = bar.dataset.freeShippingUnlocked || '';
        } else {
          const remaining = money(Math.max(0, threshold - total), bar.dataset.moneyFormat || bar.closest('[data-cart-drawer]')?.dataset.moneyFormat);
          message.textContent = (bar.dataset.freeShippingRemaining || '').replace('__AMOUNT__', remaining);
        }
      }
    });
  }
  function createCartLine(item, drawer) {
    const row = document.createElement('div');
    row.className = 'cart-item';
    row.dataset.cartLine = '';
    row.dataset.cartLineKey = item.key;
    row.dataset.quantity = String(item.quantity);
    if (item.image) {
      const image = document.createElement('img');
      image.className = 'cart-item-img';
      image.src = item.image;
      image.alt = item.product_title || item.title || '';
      image.width = 80;
      image.height = 80;
      image.loading = 'lazy';
      row.appendChild(image);
    }
    const info = document.createElement('div');
    info.className = 'cart-item-info';
    const title = document.createElement('div');
    title.className = 'cart-item-title';
    title.textContent = item.product_title || item.title || '';
    info.appendChild(title);
    if (item.variant_title && !item.variant_title.includes('Default')) {
      const variant = document.createElement('div');
      variant.className = 'cart-item-variant';
      variant.textContent = item.variant_title;
      info.appendChild(variant);
    }
    const price = document.createElement('div');
    price.className = 'cart-item-price';
    price.dataset.linePrice = '';
    price.textContent = money(item.final_line_price, drawer.dataset.moneyFormat);
    info.appendChild(price);
    const controls = document.createElement('div');
    controls.className = 'cart-quantity-controls';
    const decrease = document.createElement('button');
    decrease.type = 'button';
    decrease.dataset.cartQuantity = '-1';
    decrease.setAttribute('aria-label', drawer.dataset.cartDecreaseLabel || 'Decrease quantity');
    decrease.textContent = '−';
    const quantity = document.createElement('span');
    quantity.dataset.lineQuantity = '';
    quantity.textContent = String(item.quantity);
    const increase = document.createElement('button');
    increase.type = 'button';
    increase.dataset.cartQuantity = '1';
    increase.setAttribute('aria-label', drawer.dataset.cartIncreaseLabel || 'Increase quantity');
    increase.textContent = '+';
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'cart-remove-button';
    remove.dataset.cartRemove = '';
    remove.setAttribute('aria-label', drawer.dataset.cartRemoveLabel || 'Remove item');
    remove.textContent = drawer.dataset.cartRemoveLabel || 'Remove item';
    controls.append(decrease, quantity, increase, remove);
    info.appendChild(controls);
    row.appendChild(info);
    return row;
  }
  function renderCartDrawer(cart) {
    const drawer = document.querySelector('[data-cart-drawer]');
    if (!drawer || !cart) return;
    cartState = cart;
    const items = drawer.querySelector('[data-cart-items]');
    const footer = drawer.querySelector('[data-cart-footer]');
    const error = drawer.querySelector('[data-cart-error]');
    const status = drawer.querySelector('[data-cart-status]');
    const count = Number(cart.item_count || 0);
    drawer.querySelector('[data-cart-drawer-count]').textContent = `(${count})`;
    document.querySelectorAll('.cart-count').forEach((badge) => {
      badge.textContent = String(count);
      badge.style.display = count ? '' : 'none';
    });
    if (items) {
      items.textContent = '';
      if (!count) {
        const empty = document.createElement('div');
        empty.className = 'cart-empty';
        const icon = document.createElement('div');
        icon.className = 'cart-empty-icon';
        icon.textContent = '🛍️';
        const message = document.createElement('p');
        message.textContent = drawer.dataset.cartEmptyLabel || '';
        const link = document.createElement('a');
        link.href = drawer.dataset.emptyUrl || rootPath;
        link.className = 'btn btn-primary btn-sm';
        link.textContent = drawer.dataset.cartEmptyCta || '';
        empty.append(icon, message, link);
        items.appendChild(empty);
      } else {
        (cart.items || []).forEach((item) => items.appendChild(createCartLine(item, drawer)));
      }
    }
    if (footer) footer.hidden = !count;
    const subtotal = drawer.querySelector('[data-cart-subtotal]');
    if (subtotal) subtotal.textContent = money(cart.total_price, drawer.dataset.moneyFormat);
    if (error) { error.hidden = true; error.textContent = ''; }
    if (status) { status.hidden = true; status.textContent = ''; }
    updateShippingProgress(cart);
  }
  async function refreshCartDrawer() {
    const drawer = document.querySelector('[data-cart-drawer]');
    if (!drawer || !window.fetch) return;
    try {
      const response = await fetch(rootPath + 'cart.js', { headers: { Accept: 'application/json' } });
      if (!response.ok) throw new Error(drawer.dataset.cartUpdateError || 'Could not load cart.');
      renderCartDrawer(await response.json());
    } catch (error) {
      const errorEl = drawer.querySelector('[data-cart-error]');
      if (errorEl) { errorEl.textContent = error.message || drawer.dataset.cartUpdateError || ''; errorEl.hidden = false; }
    }
  }
  function initCartDrawer() {
    const drawer = document.querySelector('[data-cart-drawer]');
    if (!drawer) return;
    drawer.addEventListener('click', async (event) => {
      const control = event.target.closest('[data-cart-quantity], [data-cart-remove]');
      if (!control) return;
      const line = control.closest('[data-cart-line]');
      if (!line) return;
      if (!cartState) await refreshCartDrawer();
      const item = (cartState?.items || []).find((entry) => entry.key === line.dataset.cartLineKey);
      if (!item) return;
      const requested = control.hasAttribute('data-cart-remove') ? 0 : Math.max(0, Number(item.quantity) + Number(control.dataset.cartQuantity || 0));
      drawer.querySelectorAll('[data-cart-quantity], [data-cart-remove]').forEach((button) => { button.disabled = true; });
      const error = drawer.querySelector('[data-cart-error]');
      const status = drawer.querySelector('[data-cart-status]');
      if (status) { status.textContent = drawer.dataset.cartUpdatingLabel || 'Updating cart…'; status.hidden = false; }
      try {
        const response = await fetch(rootPath + 'cart/change.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({ id: item.key, quantity: requested })
        });
        const updatedCart = await response.json();
        if (!response.ok) throw new Error(updatedCart.description || updatedCart.message || drawer.dataset.cartUpdateError || 'Could not update cart.');
        renderCartDrawer(updatedCart);
        document.dispatchEvent(new CustomEvent('cart:updated', { detail: updatedCart }));
      } catch (updateError) {
        const status = drawer.querySelector('[data-cart-status]');
        if (status) status.hidden = true;
        if (error) { error.textContent = updateError.message || drawer.dataset.cartUpdateError || ''; error.hidden = false; }
        drawer.querySelectorAll('[data-cart-quantity], [data-cart-remove]').forEach((button) => { button.disabled = false; });
      }
    });
    refreshCartDrawer();
  }
  function initCountdowns() {
    document.querySelectorAll('[data-countdown]').forEach((countdown) => {
      const endAt = Date.parse(countdown.dataset.countdownEnd || '');
      const section = countdown.closest('[data-promo-countdown-section]');
      const update = () => {
        if (!Number.isFinite(endAt)) {
          countdown.hidden = true;
          return false;
        }
        const remaining = endAt - Date.now();
        if (remaining <= 0) {
          countdown.hidden = true;
          if (section && countdown.dataset.countdownHide === 'true') section.hidden = true;
          return false;
        }
        const values = {
          days: Math.floor(remaining / 86400000),
          hours: Math.floor((remaining % 86400000) / 3600000),
          minutes: Math.floor((remaining % 3600000) / 60000),
          seconds: Math.floor((remaining % 60000) / 1000)
        };
        Object.entries(values).forEach(([unit, value]) => {
          const node = countdown.querySelector(`[data-countdown-${unit}]`);
          if (node) node.textContent = String(value).padStart(2, '0');
        });
        return true;
      };
      if (update()) {
        const timer = window.setInterval(() => { if (!update()) window.clearInterval(timer); }, 1000);
      }
    });
  }
  function initMarketingPopup() {
    const popup = document.querySelector('[data-marketing-popup]');
    if (!popup) return;
    const days = Number(popup.dataset.frequency || 0);
    const key = 'novacart:marketing-popup:dismissed';
    let dismissedThisSession = false;
    const wasDismissed = () => {
      try {
        if (days > 0) {
          const dismissedAt = Number(window.localStorage.getItem(key) || 0);
          return dismissedAt > 0 && Date.now() - dismissedAt < days * 86400000;
        }
        return dismissedThisSession || window.sessionStorage.getItem(key) === '1';
      } catch (_) { return dismissedThisSession; }
    };
    const rememberDismissal = () => {
      dismissedThisSession = true;
      try {
        if (days > 0) window.localStorage.setItem(key, String(Date.now()));
        else window.sessionStorage.setItem(key, '1');
      } catch (_) {}
    };
    const show = () => {
      if (wasDismissed() || popup.open) return;
      if (typeof popup.showModal === 'function') popup.showModal();
      else popup.setAttribute('open', '');
    };
    popup.querySelector('[data-marketing-popup-close]')?.addEventListener('click', () => popup.close());
    popup.addEventListener('click', (event) => { if (event.target === popup) popup.close(); });
    popup.addEventListener('close', rememberDismissal);
    popup.querySelector('[data-marketing-popup-link]')?.addEventListener('click', rememberDismissal);
    if (popup.dataset.trigger === 'exit' && !window.matchMedia('(hover: none)').matches) {
      document.addEventListener('mouseout', (event) => {
        if (event.clientY <= 0 && !event.relatedTarget) show();
      }, { once: true });
    } else {
      window.setTimeout(show, Math.max(0, Number(popup.dataset.delay || 8) * 1000));
    }
  }
  function initCodeCopy() {
    document.querySelectorAll('[data-copy-code]').forEach((button) => {
      button.addEventListener('click', async () => {
        const code = button.dataset.code || '';
        if (!code) return;
        let copied = false;
        try {
          if (navigator.clipboard && window.isSecureContext) {
            await navigator.clipboard.writeText(code);
            copied = true;
          } else {
            const input = document.createElement('textarea');
            input.value = code;
            input.setAttribute('readonly', '');
            input.style.position = 'fixed';
            input.style.opacity = '0';
            document.body.appendChild(input);
            input.select();
            copied = document.execCommand('copy');
            input.remove();
          }
        } catch (_) { copied = false; }
        const label = button.querySelector('span');
        if (label) {
          const initial = label.dataset.initialLabel || label.textContent;
          label.dataset.initialLabel = initial;
          label.textContent = copied ? (document.documentElement.dataset.copySuccess || 'Copied') : (document.documentElement.dataset.copyError || 'Could not copy');
          window.setTimeout(() => { label.textContent = initial; }, 2200);
        }
      });
    });
  }
  document.addEventListener('DOMContentLoaded', function () {
    initQuickView();
    initProductEnhancements();
    initCartDrawer();
    initCountdowns();
    initMarketingPopup();
    initCodeCopy();
    const mobileOverlay = document.getElementById('mobile-overlay');
    const cartOverlay = document.getElementById('cart-drawer-overlay');
    if (mobileOverlay) mobileOverlay.addEventListener('click', window.closeMobileMenu);
    if (cartOverlay) cartOverlay.addEventListener('click', window.closeCartDrawer);
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        window.closeCartDrawer();
        window.closeMobileMenu();
      }
    });
    document.querySelectorAll('[data-open-cart]').forEach((button) => {
      button.addEventListener('click', function (event) {
        event.preventDefault();
        window.openCartDrawer();
      });
    });
    document.querySelectorAll('[data-product-root]').forEach(initProduct);
  });
  const NOVACART_WISHLIST_KEY = 'novacart:wishlist:v1';
  const NOVACART_COMPARE_KEY = 'novacart:compare:v1';
  function readProductList(key) {
    try { const parsed = JSON.parse(window.localStorage.getItem(key) || '[]'); return Array.isArray(parsed) ? parsed : []; }
    catch (_) { return []; }
  }
  function writeProductList(key, value) {
    try { window.localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch (_) { return false; }
  }
  function updateFeatureCounts() {
    const wishlist = readProductList(NOVACART_WISHLIST_KEY);
    const compare = readProductList(NOVACART_COMPARE_KEY);
    document.querySelectorAll('[data-wishlist-count]').forEach((el) => { el.textContent = String(wishlist.length); });
    document.querySelectorAll('[data-compare-count]').forEach((el) => { el.textContent = String(compare.length); });
    document.querySelectorAll('[data-wishlist-toggle]').forEach((button) => {
      const active = wishlist.some((item) => String(item.id) === String(button.dataset.productId));
      button.classList.toggle('is-active', active); button.setAttribute('aria-pressed', active ? 'true' : 'false');
      button.textContent = active ? '♥' : '♡';
    });
    document.querySelectorAll('[data-compare-toggle]').forEach((button) => {
      const active = compare.some((item) => String(item.id) === String(button.dataset.productId));
      button.classList.toggle('is-active', active); button.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
  }
  function productFromButton(button) {
    return { id: String(button.dataset.productId || ''), handle: button.dataset.productHandle || '', title: button.dataset.productTitle || '', url: button.dataset.productUrl || '' };
  }
  document.addEventListener('click', function (event) {
    const wishlistButton = event.target.closest('[data-wishlist-toggle]');
    const compareButton = event.target.closest('[data-compare-toggle]');
    if (!wishlistButton && !compareButton) return;
    event.preventDefault(); event.stopPropagation();
    const button = wishlistButton || compareButton;
    const key = wishlistButton ? NOVACART_WISHLIST_KEY : NOVACART_COMPARE_KEY;
    let list = readProductList(key);
    const product = productFromButton(button);
    const exists = list.some((item) => String(item.id) === product.id);
    if (exists) list = list.filter((item) => String(item.id) !== product.id);
    else {
      if (compareButton && list.length >= 4) {
        window.alert(document.documentElement.lang === 'ar' ? 'يمكن مقارنة 4 منتجات كحد أقصى.' : (document.documentElement.lang === 'fr' ? 'Vous pouvez comparer jusqu’à 4 produits.' : 'You can compare up to 4 products.'));
        return;
      }
      list.push(product);
    }
    if (!writeProductList(key, list)) {
      window.alert(document.documentElement.lang === 'ar' ? 'تعذر حفظ الاختيار في هذا المتصفح.' : 'Could not save this choice in your browser.');
    }
    updateFeatureCounts();
  });
  document.addEventListener('DOMContentLoaded', updateFeatureCounts);
  if (document.readyState !== 'loading') updateFeatureCounts();
  (function initProductSearch() {
    const overlay = document.querySelector('[data-search-overlay]');
    if (!overlay) return;
    const openButtons = document.querySelectorAll('[data-open-search]');
    const closeEls = overlay.querySelectorAll('[data-close-search]');
    const input = overlay.querySelector('[data-search-input]');
    const resultsEl = overlay.querySelector('[data-search-results]');
    const loadingEl = overlay.querySelector('[data-search-loading]');
    const hintEl = overlay.querySelector('[data-search-hint]');
    const viewAll = overlay.querySelector('[data-search-view-all]');
    const form = overlay.querySelector('[data-search-form]');
    let debounceTimer = null;
    let lastQuery = '';
    let activeController = null;
    const moneyFormat = (window.Shopify && window.Shopify.money_format) || '${{amount}}';
    function formatMoney(cents) {
      if (window.Shopify && typeof window.Shopify.formatMoney === 'function') {
        return window.Shopify.formatMoney(cents, moneyFormat);
      }
      const value = (Number(cents) / 100).toFixed(2);
      return moneyFormat.replace(/\{\{\s*amount\s*\}\}/, value).replace(/\{\{\s*amount_no_decimals\s*\}\}/, String(Math.round(Number(cents) / 100)));
    }
    function openSearch() {
      overlay.hidden = false;
      document.body.classList.add('search-open');
      openButtons.forEach((btn) => btn.setAttribute('aria-expanded', 'true'));
      window.setTimeout(() => input && input.focus(), 30);
    }
    function closeSearch() {
      overlay.hidden = true;
      document.body.classList.remove('search-open');
      openButtons.forEach((btn) => btn.setAttribute('aria-expanded', 'false'));
      if (activeController) {
        activeController.abort();
        activeController = null;
      }
    }
    openButtons.forEach((btn) => btn.addEventListener('click', openSearch));
    closeEls.forEach((el) => el.addEventListener('click', closeSearch));
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !overlay.hidden) closeSearch();
    });
    function setLoading(on) {
      if (loadingEl) loadingEl.hidden = !on;
      if (hintEl) hintEl.hidden = on || (resultsEl && !resultsEl.hidden);
    }
    function renderProducts(products, query) {
      if (!resultsEl) return;
      resultsEl.innerHTML = '';
      if (!products || !products.length) {
        resultsEl.hidden = true;
        if (hintEl) {
          hintEl.hidden = false;
          hintEl.textContent = (document.documentElement.lang === 'ar')
            ? 'لا توجد منتجات مطابقة'
            : (document.documentElement.lang === 'fr' ? 'Aucun produit trouvé' : 'No matching products');
        }
        if (viewAll) viewAll.hidden = true;
        return;
      }
      if (hintEl) hintEl.hidden = true;
      resultsEl.hidden = false;
      const list = document.createElement('div');
      list.className = 'search-suggest-list';
      products.forEach((product) => {
        const a = document.createElement('a');
        a.className = 'search-suggest-item';
        a.href = product.url;
        const imgWrap = document.createElement('div');
        imgWrap.className = 'search-suggest-image';
        if (product.image) {
          const img = document.createElement('img');
          img.src = product.image;
          img.alt = product.title || '';
          img.loading = 'lazy';
          img.width = 64;
          img.height = 64;
          imgWrap.appendChild(img);
        } else {
          imgWrap.innerHTML = '<span aria-hidden="true">📦</span>';
        }
        const info = document.createElement('div');
        info.className = 'search-suggest-info';
        const title = document.createElement('strong');
        title.textContent = product.title || '';
        info.appendChild(title);
        if (product.type) {
          const type = document.createElement('span');
          type.className = 'search-suggest-type';
          type.textContent = product.type;
          info.appendChild(type);
        }
        if (typeof product.price === 'number') {
          const price = document.createElement('span');
          price.className = 'search-suggest-price';
          price.textContent = formatMoney(product.price);
          info.appendChild(price);
        }
        a.appendChild(imgWrap);
        a.appendChild(info);
        list.appendChild(a);
      });
      resultsEl.appendChild(list);
      if (viewAll) {
        viewAll.hidden = false;
        const base = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || '/';
        viewAll.href = base + 'search?q=' + encodeURIComponent(query) + '&type=product&options%5Bprefix%5D=last';
      }
    }
    async function runSearch(query) {
      if (!query || query.length < 1) {
        if (resultsEl) { resultsEl.hidden = true; resultsEl.innerHTML = ''; }
        if (viewAll) viewAll.hidden = true;
        if (hintEl) {
          hintEl.hidden = false;
          hintEl.textContent = (document.documentElement.lang === 'ar')
            ? 'ابدأ بالكتابة للبحث عن المنتجات'
            : (document.documentElement.lang === 'fr' ? 'Commencez à écrire pour rechercher des produits' : 'Start typing to search products');
        }
        setLoading(false);
        return;
      }
      if (activeController) activeController.abort();
      activeController = new AbortController();
      setLoading(true);
      try {
        const root = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || '/';
        const url = root + 'search/suggest.json?q=' + encodeURIComponent(query) + '&resources[type]=product&resources[limit]=8&resources[options][unavailable_products]=last';
        const res = await fetch(url, { signal: activeController.signal, headers: { 'Accept': 'application/json' } });
        if (!res.ok) throw new Error('search failed');
        const data = await res.json();
        const products = (((data || {}).resources || {}).results || {}).products || [];
        renderProducts(products.map((p) => ({
          title: p.title,
          url: p.url,
          image: p.image,
          price: p.price,
          type: p.type || p.product_type || ''
        })), query);
      } catch (err) {
        if (err && err.name === 'AbortError') return;
        if (resultsEl) {
          resultsEl.hidden = false;
          resultsEl.innerHTML = '<p class="search-suggest-error">' +
            (document.documentElement.lang === 'ar' ? 'تعذر إكمال البحث' : 'Could not complete search') +
            '</p>';
        }
      } finally {
        setLoading(false);
      }
    }
    if (input) {
      input.addEventListener('input', function () {
        const q = (input.value || '').trim();
        if (q === lastQuery) return;
        lastQuery = q;
        window.clearTimeout(debounceTimer);
        debounceTimer = window.setTimeout(() => runSearch(q), 220);
      });
    }
    if (form) {
      form.addEventListener('submit', function () {
      });
    }
  })();
  (function initCollectionFilters() {
    const filters = document.querySelector('[data-collection-filters]');
    const form = document.getElementById('CollectionFiltersForm');
    if (!filters && !form) return;
    const openBtn = document.querySelector('[data-open-filters]');
    const closeEls = document.querySelectorAll('[data-close-filters]');
    const backdrop = document.querySelector('.collection-filters-backdrop');
    const sortSelect = document.querySelector('[data-sort-select]');
    const sortHidden = form ? form.querySelector('[data-filter-sort-value]') : null;
    function openFilters() {
      if (!filters) return;
      filters.classList.add('is-open');
      if (backdrop) backdrop.hidden = false;
      document.body.classList.add('filters-open');
    }
    function closeFilters() {
      if (!filters) return;
      filters.classList.remove('is-open');
      if (backdrop) backdrop.hidden = true;
      document.body.classList.remove('filters-open');
    }
    if (openBtn) openBtn.addEventListener('click', openFilters);
    closeEls.forEach((el) => el.addEventListener('click', closeFilters));
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeFilters();
    });
    if (sortSelect && form) {
      sortSelect.addEventListener('change', function () {
        if (sortHidden) sortHidden.value = sortSelect.value;
        if (sortSelect.form === form || form.contains(sortSelect) || sortSelect.getAttribute('form') === 'CollectionFiltersForm') {
          form.submit();
        } else {
          const url = new URL(window.location.href);
          url.searchParams.set('sort_by', sortSelect.value);
          window.location.href = url.toString();
        }
      });
    }
    if (form) {
      form.querySelectorAll('[data-auto-filter]').forEach((input) => {
        input.addEventListener('change', function () {
          if (window.matchMedia('(min-width: 991px)').matches) {
            form.submit();
          }
        });
      });
    }
  })();
  window.NovaCartAppLoaded = true;
})();
