# NovaCart Theme Source (v1.6.7)

Full editable source — matches NovaCart_Shopify_Theme_Upload_v1.6.7.zip.

## Upload to Shopify
Use the zip at the package root:

**NovaCart_Shopify_Theme_Upload_v1.6.7.zip**

Shopify Admin → Online Store → Themes → Add theme → Upload zip file.

## Structure
- assets/ — CSS + JS (modular)
- config/ — settings_schema.json, settings_data.json
- layout/ — theme.liquid
- locales/ — en.default.json, ar.json, fr.json, es.json
- sections/ — Theme Editor sections
- templates/ — JSON templates

## Customize in Theme Editor
- Header group → Customize (global)
- Header group → Header (colors, announcement, currency blocks)
- Template sections per page

See ../CUSTOMER_GUIDE.md and the PDF guides in the package root.
